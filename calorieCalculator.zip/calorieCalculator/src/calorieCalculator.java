import java.util.Scanner;


public class calorieCalculator {
    /** @author 6354647
     * Titile: IntelliJ Programming Challenge #1 - Calories Consumed & Burned
     * Semester: Spring2023 - COP2210
     * Prof Charters & UTA Miguel
     * Description: This program gets daily calories consumed and burned, and then computes total net calories
     * for the week.
     *
     */

    public static Scanner keyboard = new Scanner(System.in);
    static int day1CalConsumed, day2CalConsumed, day3CalConsumed, day4CalConsumed,
            day5CalConsumed, day6CalConsumed, day7CalConsumed, day1CalBurned,
            day2CalBurned, day3CalBurned, day4CalBurned, day5CalBurned, day6CalBurned,
            day7CalBurned, totalCaloriesConsumed, totalCaloriesBurned ;
    static double     averageCaloriesConsumed, averageCaloriesBurned, netWeeklyPounds;

    /**
     * main method calls 3 methods:
     * getUserInput(), calculateCalories(), and displayCalories().
     *
     */
    public static void main(String[] args) {
        getUserInput();
        calculateCalories();
        displayCalories();
    }
   /**
    * This method gets 14 input from users about how much calorie they consumed and burned.
    */
    public static void getUserInput() {
        System.out.println("Enter calories consumed for day #1: ");
        day1CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #1: ");
        day1CalBurned = keyboard.nextInt();

        System.out.println("Enter calories consumed for day #2: ");
        day2CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #2: ");
        day2CalBurned = keyboard.nextInt();

        System.out.println("Enter calories consumed for day #3: ");
        day3CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #3: ");
        day3CalBurned = keyboard.nextInt();

        System.out.println("Enter calories consumed for day #4: ");
        day4CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #4: ");
        day4CalBurned = keyboard.nextInt();

        System.out.println("Enter calories consumed for day #5: ");
        day5CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #5: ");
        day5CalBurned = keyboard.nextInt();

        System.out.println("Enter calories consumed for day #6: ");
        day6CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #6: ");
        day6CalBurned = keyboard.nextInt();

        System.out.println("Enter calories consumed for day #7: ");
        day7CalConsumed = keyboard.nextInt();

        System.out.println("Enter calories burned for day #7: ");
        day7CalBurned = keyboard.nextInt();

    }


    /** The method below calculates the total Calories burned and consumed, average calories burned and consumed
     * as well as net weekly pounds gained or lost.
     */
    public static void calculateCalories() {


         totalCaloriesConsumed =   day1CalConsumed + day2CalConsumed + day3CalConsumed + day4CalConsumed +
                day5CalConsumed + day6CalConsumed + day7CalConsumed;


        totalCaloriesBurned =  day1CalBurned + day2CalBurned + day3CalBurned + day4CalBurned + day5CalBurned +
                day6CalBurned + day7CalBurned;


        averageCaloriesConsumed = totalCaloriesConsumed / 7.0;


        averageCaloriesBurned = totalCaloriesBurned / 7.0;


        netWeeklyPounds = (double)(totalCaloriesConsumed - totalCaloriesBurned) / (3000.0);


    }
    /**The method below displays the total Calories burned and consumed, average calories burned and consumed
     * as well as net weekly pounds gained or lost.
     */
    public static void displayCalories() {

        System.out.printf("You consumed a total of %, d calories this week. \n", totalCaloriesConsumed );

        System.out.printf("You burned a total of %, d calories this week.\n", totalCaloriesBurned);
        System.out.printf("You consumed an average of %, .2f calories a day.\n ", averageCaloriesConsumed);
        System.out.printf("You burned an average of %, .2f calories a day.\n", averageCaloriesBurned);

        System.out.print("Your net weekly gain / loss were " );
        System.out.printf("%, .3f pounds.\n", netWeeklyPounds  );
    }
}

